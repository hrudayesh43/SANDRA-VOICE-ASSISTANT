import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { getWeather } from '@/services/weatherService';
import WeatherWidget from '@/components/WeatherWidget';
import { 
  Mic, 
  MicOff, 
  Play, 
  Clock, 
  Cloud, 
  Search, 
  Smile, 
  Globe, 
  Code,
  Calendar,
  Bell,
  Volume2
} from 'lucide-react';

interface Message {
  type: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

const VoiceAssistant = () => {
  const [isListening, setIsListening] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [currentTime, setCurrentTime] = useState(new Date());
  const { toast } = useToast();

  // Update time every second
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const addMessage = (content: string, type: 'user' | 'assistant') => {
    setMessages(prev => [...prev, { content, type, timestamp: new Date() }]);
  };

  const speak = (text: string) => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.8;
      utterance.pitch = 1;
      window.speechSynthesis.speak(utterance);
    }
  };

  const processCommand = (command: string) => {
    const lowerCommand = command.toLowerCase();
    
    if (lowerCommand.includes('play')) {
      const song = command.replace(/play/i, '').trim();
      const response = `Playing ${song} on YouTube 🎶`;
      addMessage(response, 'assistant');
      speak(response);
      window.open(`https://www.youtube.com/results?search_query=${encodeURIComponent(song)}`, '_blank');
    }
    else if (lowerCommand.includes('time')) {
      const timeStr = currentTime.toLocaleTimeString();
      const response = `The current time is ${timeStr} ⏰`;
      addMessage(response, 'assistant');
      speak(response);
    }
    else if (lowerCommand.includes('date')) {
      const dateStr = currentTime.toLocaleDateString('en-US', { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
      });
      const response = `Today's date is ${dateStr}`;
      addMessage(response, 'assistant');
      speak(response);
    }
    else if (lowerCommand.includes('weather')) {
      const cityMatch = command.match(/weather in (.+)/i);
      const city = cityMatch ? cityMatch[1].trim() : 'Visakhapatnam';
      
      addMessage(`Getting weather for ${city}...`, 'assistant');
      speak(`Getting weather for ${city}`);
      
      getWeather(city)
        .then(data => {
          const response = `The weather in ${data.city} is currently ${data.description}. The temperature is ${data.temperature}°C with humidity of ${data.humidity}%.`;
          addMessage(response, 'assistant');
          speak(response);
        })
        .catch(() => {
          const errorResponse = `Sorry, I couldn't get the weather for ${city}. Please try again.`;
          addMessage(errorResponse, 'assistant');
          speak(errorResponse);
        });
    }
    else if (lowerCommand.includes('who is')) {
      const person = command.replace(/who is/i, '').trim();
      const response = `Let me search for information about ${person}...`;
      addMessage(response, 'assistant');
      speak(response);
      window.open(`https://en.wikipedia.org/wiki/${encodeURIComponent(person)}`, '_blank');
    }
    else if (lowerCommand.includes('joke')) {
      const jokes = [
        "Why don't scientists trust atoms? Because they make up everything!",
        "I told my wife she was drawing her eyebrows too high. She looked surprised.",
        "Why do programmers prefer dark mode? Because light attracts bugs!",
        "What do you call a bear with no teeth? A gummy bear!"
      ];
      const joke = jokes[Math.floor(Math.random() * jokes.length)];
      addMessage(joke, 'assistant');
      speak(joke);
    }
    else if (lowerCommand.includes('open') && lowerCommand.includes('.com')) {
      const website = command.match(/open\s+(.+\.com)/i)?.[1];
      if (website) {
        const response = `Opening ${website} 🚀`;
        addMessage(response, 'assistant');
        speak(response);
        window.open(`https://${website}`, '_blank');
      }
    }
    else if (lowerCommand.includes('remind me')) {
      const response = "I'll set up reminders for you! This feature will be enhanced with local storage.";
      addMessage(response, 'assistant');
      speak(response);
    }
    else {
      const response = "I'm here to help! Try asking me to play music, tell time, check weather, or tell a joke.";
      addMessage(response, 'assistant');
      speak(response);
    }
  };

  const startListening = () => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
      const recognition = new SpeechRecognition();
      
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'en-US';
      
      recognition.onstart = () => {
        setIsListening(true);
        toast({
          title: "🎧 Listening...",
          description: "Speak your command now"
        });
      };
      
      recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        addMessage(transcript, 'user');
        processCommand(transcript);
      };
      
      recognition.onerror = () => {
        toast({
          title: "❌ Error",
          description: "Could not recognize speech. Please try again."
        });
      };
      
      recognition.onend = () => {
        setIsListening(false);
      };
      
      recognition.start();
    } else {
      toast({
        title: "⚠️ Not Supported",
        description: "Speech recognition is not supported in this browser"
      });
    }
  };

  const handleTextSubmit = () => {
    if (inputText.trim()) {
      addMessage(inputText, 'user');
      processCommand(inputText);
      setInputText('');
    }
  };

  const quickActions = [
    { icon: Play, label: 'Play Music', command: 'play some music' },
    { icon: Clock, label: 'Current Time', command: 'what time is it' },
    { icon: Calendar, label: 'Today\'s Date', command: 'what is today\'s date' },
    { icon: Cloud, label: 'Weather', command: 'how is the weather' },
    { icon: Search, label: 'Wikipedia', command: 'who is albert einstein' },
    { icon: Smile, label: 'Tell Joke', command: 'tell me a joke' }
  ];

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="gradient-hero text-transparent bg-clip-text mb-4">
            <h1 className="text-5xl font-bold mb-2">SANDRA</h1>
            <p className="text-xl opacity-90">Your Personal Voice Assistant</p>
          </div>
          <div className="text-muted-foreground">
            {currentTime.toLocaleString()}
          </div>
        </div>

        {/* Voice Control */}
        <Card className="gradient-card border-border/50 p-6 mb-6 text-center">
          <div className="flex flex-col items-center space-y-4">
            <Button
              onClick={startListening}
              disabled={isListening}
              size="lg"
              className={`w-20 h-20 rounded-full ${isListening ? 'voice-listening voice-glow' : 'voice-pulse'} gradient-voice border-0 hover:scale-105 transition-transform`}
            >
              {isListening ? (
                <MicOff className="w-8 h-8" />
              ) : (
                <Mic className="w-8 h-8" />
              )}
            </Button>
            <p className="text-muted-foreground">
              {isListening ? 'Listening... Speak now!' : 'Click to start voice command'}
            </p>
          </div>
        </Card>

        {/* Text Input */}
        <Card className="gradient-card border-border/50 p-4 mb-6">
          <div className="flex space-x-2">
            <Input
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Type your command here..."
              onKeyPress={(e) => e.key === 'Enter' && handleTextSubmit()}
              className="bg-secondary border-border"
            />
            <Button onClick={handleTextSubmit} className="gradient-voice">
              Send
            </Button>
          </div>
        </Card>

        {/* Quick Actions */}
        <Card className="gradient-card border-border/50 p-6 mb-6">
          <h3 className="text-lg font-semibold mb-4 text-voice-primary">Quick Actions</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {quickActions.map((action, index) => (
              <Button
                key={index}
                variant="secondary"
                className="h-auto p-4 flex flex-col items-center space-y-2 hover:bg-voice-primary/20 transition-colors"
                onClick={() => processCommand(action.command)}
              >
                <action.icon className="w-6 h-6 text-voice-primary" />
                <span className="text-sm">{action.label}</span>
              </Button>
            ))}
          </div>
        </Card>

        {/* Weather Widget */}
        <div className="mb-6">
          <WeatherWidget />
        </div>

        {/* Chat Messages */}
        <Card className="gradient-card border-border/50 p-6">
          <h3 className="text-lg font-semibold mb-4 text-voice-primary flex items-center gap-2">
            <Volume2 className="w-5 h-5" />
            Conversation
          </h3>
          <div className="space-y-4 max-h-96 overflow-y-auto">
            {messages.length === 0 ? (
              <p className="text-muted-foreground text-center py-8">
                Start a conversation with SANDRA! Try saying "Hello" or use the quick actions above.
              </p>
            ) : (
              messages.map((message, index) => (
                <div
                  key={index}
                  className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-xs md:max-w-md p-3 rounded-lg ${
                      message.type === 'user'
                        ? 'gradient-voice text-white'
                        : 'bg-secondary text-foreground'
                    }`}
                  >
                    <p className="text-sm">{message.content}</p>
                    <p className="text-xs opacity-70 mt-1">
                      {message.timestamp.toLocaleTimeString()}
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>
        </Card>
      </div>
    </div>
  );
};

export default VoiceAssistant;
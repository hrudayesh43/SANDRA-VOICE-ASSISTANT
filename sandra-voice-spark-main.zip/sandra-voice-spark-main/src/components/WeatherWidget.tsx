import React, { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Cloud, Sun, CloudRain, Thermometer, Droplets } from 'lucide-react';
import { getWeather, WeatherData } from '@/services/weatherService';
import { useToast } from '@/hooks/use-toast';

const WeatherWidget = () => {
  const [weatherData, setWeatherData] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState(false);
  const [city, setCity] = useState('');
  const { toast } = useToast();

  const fetchWeather = async (cityName?: string) => {
    setLoading(true);
    try {
      const data = await getWeather(cityName || city || 'Visakhapatnam');
      setWeatherData(data);
      toast({
        title: "✅ Weather Updated",
        description: `Got weather data for ${data.city}`
      });
    } catch (error) {
      toast({
        title: "❌ Weather Error",
        description: "Could not fetch weather data. Please try again."
      });
    } finally {
      setLoading(false);
    }
  };

  const getWeatherIcon = (description: string) => {
    if (description.includes('rain')) return <CloudRain className="w-8 h-8 text-blue-400" />;
    if (description.includes('cloud')) return <Cloud className="w-8 h-8 text-gray-400" />;
    return <Sun className="w-8 h-8 text-yellow-400" />;
  };

  return (
    <Card className="gradient-card border-border/50 p-6">
      <h3 className="text-lg font-semibold mb-4 text-voice-primary flex items-center gap-2">
        <Cloud className="w-5 h-5" />
        Weather Information
      </h3>
      
      <div className="space-y-4">
        <div className="flex gap-2">
          <Input
            value={city}
            onChange={(e) => setCity(e.target.value)}
            placeholder="Enter city name..."
            onKeyPress={(e) => e.key === 'Enter' && fetchWeather()}
            className="bg-secondary border-border"
          />
          <Button 
            onClick={() => fetchWeather()}
            disabled={loading}
            className="gradient-voice"
          >
            {loading ? 'Loading...' : 'Get Weather'}
          </Button>
        </div>

        {weatherData && (
          <div className="bg-secondary/50 rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-xl font-semibold">{weatherData.city}</h4>
              {getWeatherIcon(weatherData.description)}
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center gap-2">
                <Thermometer className="w-4 h-4 text-red-400" />
                <span>{weatherData.temperature}°C</span>
              </div>
              <div className="flex items-center gap-2">
                <Droplets className="w-4 h-4 text-blue-400" />
                <span>{weatherData.humidity}%</span>
              </div>
            </div>
            
            <p className="text-muted-foreground mt-3 capitalize">
              {weatherData.description}
            </p>
          </div>
        )}
      </div>
    </Card>
  );
};

export default WeatherWidget;
import VoiceAssistant from '@/components/VoiceAssistant';

const Index = () => {
  return <VoiceAssistant />;
};

export default Index;

import axios from 'axios';

export interface WeatherData {
  temperature: number;
  description: string;
  humidity: number;
  city: string;
}

const WEATHER_API_KEY = 'b28fe068bfbae7775d3b4321136901ab'; // Your API key from the Python code

export const getWeather = async (city: string = 'Visakhapatnam'): Promise<WeatherData> => {
  try {
    const response = await axios.get(
      `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${WEATHER_API_KEY}&units=metric`
    );

    if (response.data.cod === 200) {
      return {
        temperature: Math.round(response.data.main.temp),
        description: response.data.weather[0].description,
        humidity: response.data.main.humidity,
        city: response.data.name
      };
    } else {
      throw new Error(response.data.message || 'Weather data not found');
    }
  } catch (error) {
    throw new Error('Failed to fetch weather data');
  }
};